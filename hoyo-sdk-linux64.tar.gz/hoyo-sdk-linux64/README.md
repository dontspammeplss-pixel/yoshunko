# hoyo-sdk

Portable and lightweight SDK server implementation in Rust.

### Usage
Just compile and run. The server uses sqlite, so no additional database setup required.

### Register an account
By default, you can register an account here: http://127.0.0.1:20100/account/register
(assuming you're running server with the default configuration)
